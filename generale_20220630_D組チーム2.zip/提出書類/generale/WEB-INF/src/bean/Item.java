package bean;

/**
 * 商品情報(出品情報)を一つのオブジェクトとしてまとめるためのDTOクラス 作成者:大田原優花
 *
 * 発送状況と入金状況を追記 作成者：田中
 *
 */
public class Item {

	// 商品ID
	private int item_id;

	// ユーザーID
	private String user_id;

	// 商品名
	private String item_name;

	// 価格
	private int price;

	// 在庫
	private int stock;

	// 種類
	private String type;

	// 備考
	private String others;

	// 登録日時
	private String insert_date;

	// 発送状況
	private String shipping_status;

	// 入金状況
	private String payment_status;

	// 注文ID
	private int order_id;

	// ニックネーム
	private String nickname;

	// システム使用料
	private int usage_fee;

	// コンストラクタ
	public Item() {
		this.item_id = 0;
		this.user_id = null;
		this.item_name = null;
		this.price = 0;
		this.stock = 0;
		this.type = null;
		this.others = null;
		this.insert_date = null;
		this.shipping_status = null;
		this.payment_status = null;
		this.order_id = 0;
		this.nickname = null;
		this.usage_fee = 0;
	}

	// 商品ID
	public int getItem_id() {
		return item_id;
	}

	// ユーザーID
	public String getUser_id() {
		return user_id;
	}

	// 商品名
	public String getItem_name() {
		return item_name;
	}

	// 価格
	public int getPrice() {
		return price;
	}

	// 種類
	public String getType() {
		return type;
	}

	// 在庫
	public int getStock() {
		return stock;
	}

	// 備考
	public String getOthers() {
		return others;
	}

	// 登録日時
	public String getInsert_date() {
		return insert_date;
	}

	// 発送状況
	public String getShipping_status() {
		return shipping_status;
	}

	// 入金状況
	public String getPayment_status() {
		return payment_status;
	}

	// 注文ID
	public int getOrder_id() {
		return this.order_id;
	}

	// ニックネーム
	public String getNickname() {
		return nickname;
	}

	// システム使用料
	public int getUsage_fee() {
		return usage_fee;
	}

	// セッター
	// 商品ID
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	// ユーザーID
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	// 商品名
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	// 価格
	public void setPrice(int price) {
		this.price = price;
	}

	// 種類
	public void setType(String type) {
		this.type = type;
	}

	// 在庫
	public void setStock(int stock) {
		this.stock = stock;
	}

	// 備考
	public void setOthers(String others) {
		this.others = others;
	}

	// 登録日時
	public void setInsert_date(String insert_date) {
		this.insert_date = insert_date;
	}

	// 発送状況
	public void setShipping_status(String shipping_status) {
		this.shipping_status = shipping_status;
	}

	// 入金状況
	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	// 注文ID
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	// ニックネーム
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	// システム使用料
	public void setUsage_fee(int usage_fee) {
		this.usage_fee = usage_fee;
	}

}
