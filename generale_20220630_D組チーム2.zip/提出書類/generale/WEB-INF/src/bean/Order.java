package bean;

/**
 * 作成者：中川優也
 *
 * 商品名,価格,種類を追記	作成者：田中
 *
 */

public class Order {
	// フィールド変数定義
	// 注文ID
	private int order_id;
	// 商品ID
	private int item_id;
	// ユーザーID
	private String user_id;
	//注文数
	private int order_quantity;
	//発送状況
	private String shipping_status;
	// 入金状況
	private String payment_status;


	// 商品名
	private String item_name;
	// 価格
	private int price;
	// 種類
	private String type;

	// コンストラクト定義
	public Order() {
		this.order_id = 0;
		this.item_id = 0;
		this.user_id = null;
		this.order_quantity = 0;
		this.shipping_status = null;
		this.payment_status = null;
		this.item_name = null;
		this.price = 0;
		this.type = null;


	}

	// セッターメソッド
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public void setOrder_quantity(int order_quantity) {
		this.order_quantity = order_quantity;
	}

	public void setShipping_status(String shipping_status) {
		this.shipping_status = shipping_status;
	}
	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}


	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setType(String type) {
		this.type = type;
	}


	// ゲッターメソッド
	public int getOrder_id() {
		return this.order_id;
	}

	public int getItem_id() {
		return this.item_id;
	}

	public String getUser_id() {
		return this.user_id;
	}

	public int getOrder_quantity() {
		return this.order_quantity;
	}

	public String getShipping_status() {
		return this.shipping_status;
	}
	public String getPayment_status() {
		return this.payment_status;
	}


	public String getItem_name() {
		return this.item_name;
	}
	public int getPrice() {
		return this.price;
	}
	public String getType() {
		return this.type;
	}

}

