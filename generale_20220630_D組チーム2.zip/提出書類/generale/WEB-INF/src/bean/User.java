package bean;

/**
 * ユーザ情報を一つのオブジェクトとしてまとめるためのDTOクラス 作成者:田中祐太
 *
 */

public class User {
	private String	user_id;			// ユーザID
	private String	password;			// パスワード
	private String	email;				// メールアドレス
	private String	user_name;			// 氏名
	private String	nickname;			// ニックネーム
	private String	address;			// 住所
	private String	authority;			// 権限
	private String insert_date;			// 登録日時

	private String shipping_status;		// 発送状況
	private String payment_status;		// 入金状況

	private int stock;					// 在庫数
	private int price;					// 価格
	private int usage_fee;				// システム利用料
	private int exhibit_count;			// 出品数


	//コンストラクタ
	public User(){
		//初期化
		this.user_id	= null;
		this.password	= null;
		this.email		= null;
		this.user_name	= null;
		this.nickname	= null;
		this.address	= null;
		this.authority	= null;
		this.insert_date = null;
		this.shipping_status = null;
		this.payment_status = null;
		this.stock = 0;
		this.price = 0;
		this.usage_fee = 0;
		this.exhibit_count = 0;

	}


	/* SETメソッド */
	public void setUser_id(String user_id){
		this.user_id = user_id;
	}

	public void setPassword(String password){
		this.password = password;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public void setUser_name(String user_name){
		this.user_name = user_name;
	}

	public void setNickname(String nickname){
		this.nickname = nickname;
	}

	public void setAddress(String address){
		this.address = address;
	}

	public void setAuthority(String authority){
		this.authority = authority;
	}

	public void setInsert_date(String insert_date){
		this.insert_date = insert_date;
	}

	public void setStock(int stock){
		this.stock = stock;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setUsage_fee(int usage_fee){
		this.usage_fee = usage_fee;
	}

	public void setShipping_status(String shipping_status) {
		this.shipping_status = shipping_status;
	}

	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	public void setExhibit_count(int exhibit_count) {
		this.exhibit_count = exhibit_count;
	}


	/* GETメソッド */
	public String getUser_id(){
		return this.user_id;
	}

	public String getPassword(){
		return this.password;
	}

	public String getEmail(){
		return this.email;
	}

	public String getUser_name(){
		return this.user_name;
	}

	public String getNickname(){
		return this.nickname;
	}

	public String getAddress(){
		return this.address;
	}

	public String getAuthority(){
		return this.authority;
	}

	public String getInsert_date(){
		return this.insert_date;
	}

	public int getStock() {
		return stock;
	}

	public int getPrice() {
		return price;
	}

	public int getUsage_fee() {
		return usage_fee;
	}

	public String getShipping_status() {
		return this.shipping_status;
	}

	public String getPayment_status() {
		return this.payment_status;
	}

	public int getExhibit_count() {
		return this.exhibit_count;
	}

}
