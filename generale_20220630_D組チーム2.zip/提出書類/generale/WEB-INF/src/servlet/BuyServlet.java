package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Item;
import bean.Order;
import bean.User;
import dao.ItemDAO;
import dao.OrderDAO;
import util.SendMail;

public class BuyServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// 変数宣言
		String error = "";
		String cmd = "";

		try {

			// セッションから"user"を取得する
			HttpSession session = request.getSession();
			User user = (User)session.getAttribute("user");

			// セッション切れの場合はerror.jspに遷移する
			if(user == null) {
				error = "セッション切れの為、購入は出来ません。";
				cmd ="logout";
				throw new Exception("nlluser");
			}

			String strItem_id = request.getParameter("item_id");

			// ItemDAOクラスのオブジェクトを生成
			ItemDAO objDao = new ItemDAO();
			OrderDAO orderdao = new OrderDAO();

			// ItemDAOクラスに定義したselectByitemid（）メソッドを利用して書籍情報を取得
			int item_id = Integer.parseInt(strItem_id);
			Item item = objDao.selectByitemid(item_id);

			Order order = new Order();
			order.setItem_id(item.getItem_id());
			order.setUser_id(user.getUser_id());
			order.setOrder_quantity(1);
			order.setShipping_status("未");
			order.setPayment_status("未");

			orderdao.insert(order);


			//"order_list"の注文情報内容をメール送信する。
			ArrayList<User> useremailList = orderdao.selectBuyuserid(item_id);
			if(useremailList != null){
				for(int i = 0; i < useremailList.size(); i++){
					User useremai = (User)useremailList.get(i);
					SendMail sendmail = new SendMail();
					sendmail.mailsend(useremai, order);
				}
			}

		} catch(IllegalStateException e) {
			// DB接続ができない場合
			error = "DB接続エラーの為、購入は出来ません。";
			cmd = "logout";

		} catch(Exception e) {
			if(cmd.equals("logout")) {
				cmd = "logout";
			} else {
				cmd = "menu";
			}

		} finally {
			// エラー有無
			if (error.equals("")) {
				// 無し
				// 「buyConrirm.jsp」へフォワードします。
				request.getRequestDispatcher("/buyingHistory").forward(request, response);

			} else {
				// 有り
				// 「error.jsp」へフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
