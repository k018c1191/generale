package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.ArrayList;

import bean.Order;
import bean.User;
import bean.Item;
import dao.OrderDAO;

/**
 * 購入履歴のサーブレット
 * 作成者：中島、田中
 *
 */


public class BuyingHistoryServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// 変数の宣言と初期化
		String error = "";
		String cmd = "";

		try {
			// セッションから"user"を取得する
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はエラー
			if (user == null) {
				error = "セッション切れの為、購入履歴の表示は出来ません。";
				cmd = "logout";
				return;
			}

			// オブジェクト生成
			OrderDAO objOrderDao = new OrderDAO();

			// selectByAccountメソッドを呼び出し、取得した購入履歴情報を ArrayListに格納する
			ArrayList<Order> buyingList = objOrderDao.selectByAccount(user);

			// 取得した書籍情報をリクエストスコープに登録
			request.setAttribute("buyingList", buyingList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入履歴の表示は出来ませんでした。";
			cmd = "menu";

		} finally {
			// エラーの有無を判定
			if (error.equals("")) {
				// エラーがない場合 buyingHistory.jspへフォワード
				request.getRequestDispatcher("/view/buyingHistory.jsp").forward(request, response);
			} else {
				// エラーがある場合 error.jspにフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}


}
