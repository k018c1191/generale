package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Item;
import dao.ItemDAO;


/**
 * 出品詳細のサーブレット
 * 作成者：中島
 *
 */

public class DetailsExhibitServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// 変数の宣言と初期化
		String error = "";
		String cmd = "";

		try {
			// 画面から送信される情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// item_idの入力パラメータを取得する
			String item_id = request.getParameter("item_id");
			cmd = request.getParameter("cmd");

			// selectByItem_idメソッドを利用し、商品情報を取得
			ItemDAO objItemDao = new ItemDAO();
			Item item = objItemDao.selectByItem_id(item_id);

			// 対象商品が存在しているかチェック
//			if (item.getItem_name() == null) {
//				error = "表示対象の商品が存在しない為、出品詳細は表示できませんでした。";
//				cmd = "list";
//				return;
//			}

			// 取得した商品情報をリクエストスコープに"item"という名前で格納する
			request.setAttribute("item", item);
			request.setAttribute("cmd", cmd);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、出品詳細は表示できませんでした。";
			cmd = "menu";

		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {

				//if (cmd.equals("detailsExhibit")) {
					request.getRequestDispatcher("/view/detailsExhibit.jsp").forward(request, response);

					// cmd情報の値を判定し、「update」の場合は「apdate.jsp」へフォワード
				//} else if (cmd.equals("update")) {
					//request.getRequestDispatcher("/view/update.jsp").forward(request, response);
				//}

			} else {
				// エラーがある場合 error.jspにフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}

}
