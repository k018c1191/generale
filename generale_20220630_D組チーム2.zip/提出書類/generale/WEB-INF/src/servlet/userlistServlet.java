package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.*;
import dao.*;

public class userlistServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//jsp画面(Web)から受け取るデータの文字コード設定
		request.setCharacterEncoding("UTF-8");
		String cmd="";
		String error = "";
		try {
			// BookDAOオブジェクトを生成
			UserDAO userDao = new UserDAO();

			// 検索した書籍情報を格納するAllayListオブジェクトを生成し、BookDAOクラスに定義した、selectAll()メソッドを利用して書籍情報を取得
			ArrayList<User> list = userDao.selectAll();

			// 取得した書籍情報を「book_list」という名前でリクエストスコープに登録
			request.setAttribute("user_list", list);

		} catch (IllegalStateException e) {
			//DBに接続できなかった場合
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd ="logout";
		} finally {
			// エラーなし
			if (error.equals("")) {
				request.getRequestDispatcher("/view/user_list.jsp").forward(request, response);
				// エラーあり
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}
	}
}
