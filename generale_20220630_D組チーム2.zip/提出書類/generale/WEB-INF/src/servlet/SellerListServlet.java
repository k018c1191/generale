package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import dao.UserDAO;

/**
 * 出品一覧のサーブレット
 * 作成者：田中祐太
 *
 */


public class SellerListServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// 変数の宣言と初期化
		String error = "";
		String cmd = "";

		try {
			// セッションから"user"を取得する
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はエラー
			if (user == null) {
				error = "セッション切れの為、購入は出来ません。";
				cmd = "logout";
				return;
			}

			// オブジェクト生成
			UserDAO objUserDao = new UserDAO();

			// selectByAccountメソッドを呼び出し、取得した出品情報を ArrayListに格納する
			ArrayList<User> sellerList = objUserDao.selectSeller();

			// 取得した出品情報をリクエストスコープに登録
			request.setAttribute("sellerList", sellerList);

			ArrayList<User> salseList = objUserDao.selectSellerSalse();
			request.setAttribute("salseList", salseList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "menu";

		} finally {
			// エラーの有無を判定
			if (error.equals("")) {
				// エラーがない場合 sellerList.jspへフォワード
				request.getRequestDispatcher("/view/sellerList.jsp").forward(request, response);
			} else {
				// エラーがある場合 error.jspにフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}

}
