package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Item;
import dao.ItemDAO;

public class DetailsItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// 変数宣言
		String error = "";
		String cmd = "";

		try {

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// 画面から送信されるitem_idとcmd情報を受け取るためのエンコードを設定
			// 画面から送信されるitem_idとcmd情報を受け取る
			String strItem_id = request.getParameter("item_id");
			cmd = request.getParameter("cmd");

			// ItemDAOクラスのオブジェクトを生成
			ItemDAO objDao = new ItemDAO();

			// ItemDAOクラスに定義したselectByitemid（）メソッドを利用して書籍情報を取得
			int item_id = Integer.parseInt(strItem_id);
			Item item = objDao.selectByitemid(item_id);

			// 取得した書籍情報を「item」という名前でリクエストスコープに登録
			request.setAttribute("item", item);

			// 詳細一覧画面のitem_idリンクをクリック時、表示対象の書籍が存在しない
			if (item.getItem_id() == 0) {
				error = "表示対象の商品が存在しない為、詳細情報は表示できませんでした。";
				throw new Exception("notitemid");
			}

		} catch(IllegalStateException e) {
			if (cmd.equals("detailsItem")) {
				// 書籍一覧画面のISBNリンクをクリック時、DBに接続できない
				error = "DB接続エラーの為、商品詳細は表示できませんでした。";
				cmd = "logout";
			}

		} catch (Exception e) {
			cmd = "itemlist";
		} finally {
			// エラー有無
			if (error.equals("")) {
				// 無し
				// cmd情報の値を判定し、「detail」の場合は「detailsItem.jsp」へフォワード
				if (cmd.equals("detailsItem")) {
					request.getRequestDispatcher("/view/detailsItem.jsp").forward(request, response);
				}

			} else {
				// 有り
				// 「error.jsp」へフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
