package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.OrderDAO;
import util.SendsendMail;

public class UpdateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 変数宣言
		String error = "";
		String cmd = "";

		try {
			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");


			// OrderDAOクラスのオブジェクトを生成
			OrderDAO orderDao = new OrderDAO();

			// パラメータの取得
			String  strOrder_id= request.getParameter("order_id");
			int order_id = Integer.parseInt(strOrder_id);
			String shipping_status = request.getParameter("shipping_status");
			String getpayment_status = request.getParameter("getpayment_status");

			if ( shipping_status == null && getpayment_status.equals("完")) {
				orderDao.paymentstatusUpdate(order_id, shipping_status);
			} else if(getpayment_status == null && shipping_status.equals("完")) {
				orderDao.shippingstatusUpdate(order_id, getpayment_status);
				User useremail = orderDao.sendSendmail(order_id);
				SendsendMail sendmail = new SendsendMail();
				sendmail.mailsend(useremail);
			}


		} catch (IllegalStateException e) {
			// DB接続ができない場合
			error = "DB接続エラーの為、更新処理は行えませんでした。";
			cmd = "logout";
		} finally {
			// エラー有無
			if (error.equals("")) {
				// 無し
				// 「」へフォワードします。
				request.getRequestDispatcher("/buyingHistory").forward(request, response);

			} else {
				// 有り
				// 「error.jsp」へフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
