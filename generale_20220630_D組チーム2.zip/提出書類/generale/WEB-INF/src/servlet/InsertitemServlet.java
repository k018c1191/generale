package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Item;
import bean.User;
import dao.ItemDAO;

/**
 * 出品登録(商品登録)のサーブレット 作成者：大田原優花
 *
 */
public class InsertitemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// 変数宣言
		String error = "";
		String cmd = "";

		try {

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// セッションから"user"を取得する
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はエラー
			if (user == null) {
				error = "セッション切れの為、購入履歴の表示は出来ません。";
				cmd = "logout";
				return;
			}

			// パラメータの取得
			String item_name = request.getParameter("item_name");
			String type = request.getParameter("type");
			String strStock = request.getParameter("stock");
			String strPrice = request.getParameter("price");
			String others = request.getParameter("others");

			// ItemDAOクラスのオブジェクトを生成
			ItemDAO objDao = new ItemDAO();

			// 登録ボタン押下時、item_nameが未入力
			if (item_name.equals("")) {
				error = "商品名が未入力の為、書籍登録処理は行えませんでした。";
				throw new Exception("notIsbn");
			}

			// 登録ボタン押下時、typeが未入力
			if (type.equals("")) {
				error = "種類が未入力の為、書籍登録処理は行えませんでした。";
				throw new Exception("notIsbn");
			}

			// 登録ボタン押下時、strStockが未入力
			if (strStock.equals("")) {
				error = "数が未入力の為、書籍登録処理は行えませんでした。";
				throw new Exception("notIsbn");
			}

			// 登録ボタン押下時、strPriceが未入力
			if (strPrice.equals("")) {
				error = "価格が未入力の為、書籍登録処理は行えませんでした。";
				throw new Exception("notIsbn");
			}

			// 登録ボタン押下時、othersが未入力
			if (others.equals("")) {
				error = "備考が未入力の為、書籍登録処理は行えませんでした。";
				throw new Exception("notIsbn");
			}

			// 登録する書籍情報を格納するitemオブジェクトを生成
			Item item = new Item();

			// 画面からの入力情報を受け取り、itemオブジェクトに格納
			item.setUser_id(user.getUser_id());
			item.setItem_name(item_name);
			item.setType(type);
			int stock = Integer.parseInt(strStock);
			item.setStock(stock);
			int price = Integer.parseInt(strPrice);
			item.setPrice(price);
			item.setOthers(others);

			// BookDAOクラスに定義したinsert（）メソッドを利用して、Bookオブジェクトに格納された書籍データをデータベースに登録
			objDao.insert(item);

		} catch (IllegalStateException e) {
			// DB接続ができない場合
			error = "DB接続エラーの為、出品登録処理は行えませんでした。";
			cmd = "logout";

		} catch (NumberFormatException e) {
			// 登録ボタン押下時、価格が数値以外
			error = "価格の値が不正の為、書籍登録処理は行えませんでした。";
			cmd = "menu";

		} catch (Exception e) {
			// Exceptionの例外list.jspへ遷移
			cmd = "menu";

		} finally {

			// エラー有無
			if (error.equals("")) {
				// 無し
				// 「ListServlet」へフォワードします。
				request.getRequestDispatcher("/itemlist").forward(request, response);

			} else {
				// 有り
				// 「error.jsp」へフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
