package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Item;
import dao.ItemDAO;

/**
 * 商品一覧サーブレット
 * 作成者：石本千栞
 *
 */
public class ItemListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			// ItemDAOクラスのオブジェクトを生成
			ItemDAO objDao = new ItemDAO();

			// 検索した商品情報を格納するAllayListオブジェクトを生成します。
			// ItemDAOクラスに定義した、selectAll()メソッドを利用して書籍情報を取得します。
			ArrayList<Item> list = objDao.selectAll();

			// 取得した書籍情報を「item_list」という名前でリクエストスコープに登録します。
			request.setAttribute("item_list", list);

		} catch (IllegalStateException e) {
			// DB接続ができない場合
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "logout";

		} finally {
			// エラー有無
			if (error.equals("")) {
				// 無し
				// 「list.jsp」へフォワードします。
				request.getRequestDispatcher("/view/itemList.jsp").forward(request, response);

			} else {
				// 有り
				// 「error.jsp」へフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
