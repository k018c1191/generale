package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import dao.UserDAO;

/**
 * ログインのサーブレット
 * 作成者：石本千栞
 *
 */
public class loginServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// 変数宣言
		String error = "";
		String cmd = "";

		try {
			// userid, password入力パラメータを取得する。
			String user_id = request.getParameter("userid");
			String password = request.getParameter("password");

			// UserDAOをインスタンス化し、関連メソッドを呼び出す。
			UserDAO userDaoObj = new UserDAO();
			User user = userDaoObj.selectByUser_id(user_id, password);

			// ログインボタン押下時に、入力データで情報が取得できない
			if (user.getUser_id() == null) {
					error = "入力データが間違っています。";
					throw new Exception("nulluserid");
				}

			// 取得したUserオブジェクトをセッションスコープに"user"という名前で登録
			HttpSession session = request.getSession();
			session.setAttribute("user", user);


			// クッキーに入力情報のuseridとpasswordを登録する。（期間は5日間）
			Cookie userCookie = new Cookie("user", user.getUser_id());
			userCookie.setMaxAge(60 * 60 * 24 * 5);
			response.addCookie(userCookie);

			Cookie passCookie = new Cookie("password", user.getPassword());
			passCookie.setMaxAge(60 * 60 * 24 * 5);
			response.addCookie(passCookie);

		} catch (IllegalStateException e) {
			// DB接続ができない場合
			error = "DB接続エラーの為、ログインは出来ません。";
			cmd = "logout";
		} catch (Exception e) {
			cmd = "login";
		} finally {
			// エラー有無
			if (error.equals("")) {
				// 無し
				// 「menu.jsp」へフォワードします。
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);
		} else {
				// 有り
				// 「login.jsp」にフォワードする
				request.setAttribute("error", error);
				if(cmd.equals("login")) {
					request.getRequestDispatcher("/view/login.jsp").forward(request, response);
				} else {
					// 「error.jsp」へフォワード
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			}
		}
	}

}
