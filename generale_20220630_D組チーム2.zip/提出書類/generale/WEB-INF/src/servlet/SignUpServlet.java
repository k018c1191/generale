package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDAO;


public class SignUpServlet extends HttpServlet{

	public void doGet(HttpServletRequest request ,HttpServletResponse response)
	throws ServletException ,IOException {

		// 変数の宣言と初期化
		String error = "";
		String cmd = "";

		try {
			// 画面からの入力情報を受け取るためのエンコード処理
			response.setContentType("text/html; charset=UTF-8");
			request.setCharacterEncoding("UTF-8");

			// 入力パラメータを取得する
			String user_id = request.getParameter("user_id");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			String user_name = request.getParameter("user_name");
			String nickname = request.getParameter("nickname");
			String address = request.getParameter("address");
			String authority = request.getParameter("authority");


			// 取得したパラメータの各エラーチェック

			// 全データの空白チェック
			if (user_id.equals("")) {
				error = "ユーザーIDが未入力の為、ユーザー登録は行えませんでした。";
				cmd = "insertAccount";
				return;
			}

			if (password.equals("")) {
				error = "パスワードが未入力の為、ユーザー登録は行えませんでした。";
				cmd = "insertAccount";
				return;
			}

			if (email.equals("")) {
				error = "メールアドレスが未入力の為、ユーザー登録は行えませんでした。";
				cmd = "insertAccount";
				return;
			}

			if (user_name.equals("")) {
				error = "氏名が未入力の為、ユーザー登録は行えませんでした。";
				cmd = "insertAccount";
				return;
			}

			if (nickname.equals("")) {
				error = "ニックネームが未入力の為、ユーザー登録は行えませんでした。";
				cmd = "insertAccount";
				return;
			}

			if (address.equals("")) {
				error = "住所が未入力の為、ユーザー登録は行えませんでした。";
				cmd = "insertAccount";
				return;
			}


			// オブジェクト生成
			UserDAO objUserDao = new UserDAO();

			// ISBNの重複チェック
			if (objUserDao.selectByUser_id(user_id, password).getUser_id() != null) {
				error = "入力されたユーザーIDは既に存在している為、ユーザー登録は行えませんでした。";
				cmd = "insertAccount";
				return;
			}

			// Bookのオブジェクトを生成し、各setterメソッドを利用し、isbn, title, priceを設定する
			User user = new User();
			user.setUser_id(user_id);
			user.setPassword(password);
			user.setEmail(email);
			user.setUser_name(user_name);
			user.setNickname(nickname);
			user.setAddress(address);
			user.setAuthority(authority);

			// insertメソッドを利用して、Bookオブジェクトに格納された書籍データをデータベースに登録する
			objUserDao.insert(user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー登録は行えませんでした。";
			cmd = "menu";

		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// エラーが無しの場合 LoginServletにフォワード
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			} else {
				// エラーがある場合 error.jspにフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}

}
