package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Order;
import bean.User;

/**
 * 購入情報のDAO 作成者：石本千栞
 *
 */
public class OrderDAO {
	/**
	 * JDBCドライバ内部のDriverクラスパス
	 */
	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	/**
	 * 接続するMySQLデータベースパス
	 */
	private static final String URL = "jdbc:mysql://localhost/generale_db";
	/**
	 * データベースのユーザー名
	 */
	private static final String USER = "root";
	/**
	 * データベースのパスワード
	 */
	private static final String PASSWD = "root123";

	/**
	 * フィールド変数のデータベース情報を基に、DB接続をおこなう
	 *
	 * @return データベース接続情報
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// insertメゾット(石本千栞)
	public void insert(Order order) {

		// 引数の情報を利用し、登録用のSQL文を文字列として定義
//		String sql = "INSERT INTO order_info VALUES(NULL,"+ order.getItem_id() + ",'"+ order.getUser_id() +"',"
//                + order.getOrder_quantity() + "," + "'未','未')";
		String sql = "INSERT INTO order_info VALUES(NULL," + order.getItem_id() + ",'" + order.getUser_id() + "',"
				+ order.getOrder_quantity() + ",'" + order.getShipping_status() + "','" + order.getPayment_status()
				+ "')";

		// 変数宣言
		Connection con = null;
		Statement smt = null;

		try {

			// BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = getConnection();

			// ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			// Statementオブジェクトの、executeUpdate（）メソッドを利用して、SQL文を発行し、注文データを登録します。
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			// Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}

	}

	/**
	 * 購入者で商品情報と購入情報を取得するメソッド
	 *
	 * @param user 購入者のユーザー情報
	 * @return
	 */
	public ArrayList<Order> selectByAccount(User user) {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		// 検索した出品情報を格納するArrayListを生成する
		ArrayList<Order> buyingList = new ArrayList<Order>();

		// SQL文作成
		String sql = "SELECT * FROM item_info A INNER JOIN order_info B ON A.item_id=B.item_id " + "WHERE B.user_id='"
				+ user.getUser_id() + "'";

		try {

			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をオブジェクトに格納
			while (rs.next()) {
				Order buyingInfo = new Order();
				buyingInfo.setOrder_id(rs.getInt("order_id"));
				buyingInfo.setItem_id(rs.getInt("item_id"));
				buyingInfo.setItem_name(rs.getString("item_name"));
				buyingInfo.setPrice(rs.getInt("price"));
				buyingInfo.setType(rs.getString("type"));
				buyingInfo.setOrder_quantity(rs.getInt("order_quantity"));

				buyingList.add(buyingInfo);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return buyingList;

	}

	// getpayment_statusアップデート(石本千栞)
	public void paymentstatusUpdate(int order_id, String payment_status) {

		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// 引数の情報を利用し、更新用のSQL文を文字列として定義
		String sql = "UPDATE order_info SET payment_status='完' WHERE order_id=" + order_id;

		try {
			// BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = getConnection();

			// ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			// StatementオブジェクトのexecuteUpdate（）メソッドを利用して、SQL文を発行し書籍データを変更
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			// Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// getpayment_statusアップデート(石本千栞)
	public void shippingstatusUpdate(int order_id, String shipping_status) {

		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// 引数の情報を利用し、更新用のSQL文を文字列として定義
		String sql = "UPDATE order_info SET shipping_status='完' WHERE order_id=" + order_id;

		try {
			// BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = getConnection();

			// ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			// StatementオブジェクトのexecuteUpdate（）メソッドを利用して、SQL文を発行し書籍データを変更
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			// Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public ArrayList<User> selectBuyuserid(int item_id) {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		ArrayList<User> buySendmail = new ArrayList<User>();

		String sql = "SELECT * FROM item_info A INNER JOIN user_info B ON A.user_id=B.user_id WHERE A.item_id="
				+ item_id;

		try {
			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User buymail = new User();
				buymail.setUser_id(rs.getString("user_id"));
				buymail.setEmail(rs.getString("email"));
				buySendmail.add(buymail);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			// Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return buySendmail;

	}

	public User sendSendmail(int order_id) {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		User buymail = new User();

		String sql = "SELECT * FROM order_info A LEFT JOIN (SELECT * FROM item_info) AS B ON A.item_id = B.item_id INNER JOIN user_info C ON  B.user_id=C.user_id WHERE order_id="
				+ order_id;

		try {
			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				buymail.setUser_id(rs.getString("user_id"));
				buymail.setEmail(rs.getString("email"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// Statementオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			// Connectionオブジェクトをクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return buymail;

	}

}
