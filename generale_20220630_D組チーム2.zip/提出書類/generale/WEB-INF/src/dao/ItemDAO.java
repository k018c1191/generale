package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Item;
import bean.User;

/**
 * 商品情報のDAO 作成:大田原優花
 *
 */
public class ItemDAO {

	// DB情報(大田原優花)
	/**
	 * JDBCドライバ内部のDriverクラスパス
	 */
	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	/**
	 * 接続するMySQLデータベースパス
	 */
	private static final String URL = "jdbc:mysql://localhost/generale_db";
	/**
	 * データベースのユーザー名
	 */
	private static final String USER = "root";
	/**
	 * データベースのパスワード
	 */
	private static final String PASSWD = "root123";

	/**
	 * フィールド変数のデータベース情報を基に、DB接続をおこなう
	 *
	 * @return データベース接続情報
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// insertメソッド(大田原優花)
	public void insert(Item item) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "INSERT INTO item_info VALUES(NULL,'" + item.getUser_id() + "','" + item.getItem_name() + "',"
					+ item.getPrice() + "," + item.getStock() + ",'" + item.getType() + "','" + item.getOthers()
					+ "',CURDATE())";

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// selectAllメゾット(石本千栞)
	public ArrayList<Item> selectAll() {

		ArrayList<Item> list = new ArrayList<Item>();
		String sql = "SELECT * FROM item_info ORDER BY ITEM_ID";

		Connection con = null;
		Statement smt = null;

		try {

			con = ItemDAO.getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Item item = new Item();
				item.setItem_id(rs.getInt("item_id"));
				item.setUser_id(rs.getString("user_id"));
				item.setItem_name(rs.getString("item_name"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setType(rs.getString("type"));
				item.setOthers(rs.getString("others"));

				list.add(item);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}

	// selectByItemidメゾット(石本千栞)
	public Item selectByitemid(int item_id) {

		// 変数宣言
		Connection con = null;
		Statement smt = null;

		Item item = new Item();

		// 引数の情報を利用し、検索用のSQL文を文字列として定義
		String sql = "SELECT * FROM item_info WHERE item_id = " + item_id;

		try {

			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をオブジェクトに格納
			while (rs.next()) {
				item.setItem_id(rs.getInt("item_id"));
				item.setUser_id(rs.getString("user_id"));
				item.setItem_name(rs.getString("item_name"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setType(rs.getString("type"));
				item.setOthers(rs.getString("others"));
				item.setInsert_date(rs.getString("insert_date"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return item;
	}

	public ArrayList<Item> selectByAccount(User user) {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		// 検索した出品情報を格納するArrayListを生成する
		ArrayList<Item> exhibitList = new ArrayList<Item>();

		// SQL文作成
		String sql = "SELECT item_id,item_name,price,stock FROM item_info WHERE user_id = '" + user.getUser_id() + "'";

		try {

			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をオブジェクトに格納
			while (rs.next()) {
				Item exhibitInfo = new Item();
				exhibitInfo.setItem_id(rs.getInt("item_id"));
				exhibitInfo.setItem_name(rs.getString("item_name"));
				exhibitInfo.setPrice(rs.getInt("price"));
				exhibitInfo.setStock(rs.getInt("stock"));
				exhibitList.add(exhibitInfo);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return exhibitList;

	}

	public Item selectByItem_id(String item_id) {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		Item item = new Item();

		// SQL文作成
		String sql = "SELECT * FROM item_info A INNER JOIN order_info B ON A.item_id=B.item_id " + "WHERE B.item_id="
				+ "'" + item_id + "'";

		try {

			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をオブジェクトに格納
			while (rs.next()) {
				item.setItem_name(rs.getString("item_name"));
				item.setType(rs.getString("type"));
				item.setStock(rs.getInt("stock"));
				item.setPrice(rs.getInt("price"));
				item.setOthers(rs.getString("others"));
				item.setShipping_status(rs.getString("shipping_status"));
				item.setPayment_status(rs.getString("payment_status"));
				item.setOrder_id(rs.getInt("order_id"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return item;

	}

	public ArrayList<Item> selectExhibitList() {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		ArrayList<Item> exhibitList = new ArrayList<Item>();

		// SQL文作成
		String sql = "SELECT C.item_id, C.item_name, B.nickname, C.price, C.stock, A.shipping_status, A.payment_status FROM order_info A inner join user_info B on A.user_id = B.user_id inner join item_info C on A.item_id = C.item_id";

//		String sql = "SELECT C.item_id, C.item_name, B.nickname, C.price,"
//				+ "C.stock, A.shipping_status, A.payment_status"
//				+ "FROM order_info A inner join user_info B on A.user_id = B.user_id"
//				+ "inner join item_info C on A.item_id = C.item_id";

		try {
			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をオブジェクトに格納
			while (rs.next()) {
				Item item = new Item();
				item.setItem_id(rs.getInt("item_id"));
				item.setItem_name(rs.getString("item_name"));
				item.setNickname(rs.getString("nickname"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setShipping_status(rs.getString("shipping_status"));
				item.setPayment_status(rs.getString("payment_status"));
				exhibitList.add(item);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return exhibitList;

	}

}
