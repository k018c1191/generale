package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.User;

public class UserDAO {

	// データベース接続情報
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/generale_db";
	private static String USER = "root";
	private static String PASS = "root123";

	/*
	 * データベース接続を行うメソッド データベース接続用定義を基にデータベースへ接続し、戻り値としてコネクション情報を返す
	 */
	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public void insert(User user) {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		// SQL文作成
		String sql = "INSERT INTO user_info VALUES('" + user.getUser_id() + "','" + user.getPassword() + "','"
				+ user.getEmail() + "','" + user.getUser_name() + "','" + user.getNickname() + "','" + user.getAddress()
				+ "','" + user.getAuthority() + "'" + ",CURDATE())";

		try {
			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public User selectByUser_id(String user_id, String password) {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		// 検索した書籍情報を格納する User オブジェクトを生成する
		User user = new User();

		// SQL文作成
		String sql = "SELECT * FROM user_info WHERE user_id = '" + user_id + "' AND password='" + password + "'";

		try {

			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をオブジェクトに格納
			while (rs.next()) {
				user.setUser_id(rs.getString("user_id"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setUser_name(rs.getString("user_name"));
				user.setNickname(rs.getString("nickname"));
				user.setAddress(rs.getString("address"));
				user.setAuthority(rs.getString("authority"));
				user.setInsert_date(rs.getString("insert_date"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;

	}

	// ユーザー
	public ArrayList<User> selectAll() {

		ArrayList<User> list = new ArrayList<User>();
		String sql = "SELECT * FROM user_info ORDER BY insert_date ASC";

		Connection con = null;
		Statement smt = null;
		try {
			// getConnectionメソッドを利用してConnectionオブジェクトを生成します
			con = UserDAO.getConnection();
			// createStatementメソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User user = new User();
				user.setUser_id(rs.getString("user_id"));
				user.setUser_name(rs.getString("user_name"));
				user.setPassword(rs.getString("password"));
				user.setNickname(rs.getString("nickname"));
				user.setAddress(rs.getString("address"));
				user.setInsert_date(rs.getString("insert_date"));

				list.add(user);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;

	}

	public ArrayList<User> selectSeller() {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		ArrayList<User> sellerList = new ArrayList<User>();

		// SQL文作成

		String sql=  "SELECT A.user_id, A.nickname,(SELECT COUNT(B.user_id) FROM item_info GROUP BY B.user_id) AS exhibit_count FROM user_info A inner join item_info B on A.user_id = B.user_id GROUP BY B.user_id";

//		String sql = "SELECT A.user_id, A.nickname,(SELECT COUNT(B.user_id)"
//				+ "FROM item_info GROUP BY B.user_id) AS exhibit_count"
//				+ "FROM user_info A inner join item_info B on A.user_id = B.user_id" + "GROUP BY B.user_id";

		try {
			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をオブジェクトに格納
			while (rs.next()) {
				User users = new User();
				users.setUser_id(rs.getString("user_id"));
				users.setNickname(rs.getString("nickname"));
				users.setExhibit_count(rs.getInt("exhibit_count"));

				sellerList.add(users);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return sellerList;

	}

	public ArrayList<User> selectSellerSalse() {

		// 変数の宣言と初期化
		Connection con = null;
		Statement smt = null;

		ArrayList<User> sellerList = new ArrayList<User>();

		// SQL文作成
		String sql = "SELECT e.user_id,e.nickname, COUNT(F.user_id)AS exhibit_count,e. price FROM item_info F LEFT JOIN (SELECT C.user_id , C.nickname,B.item_id,(SELECT COUNT(B.user_id) FROM item_info GROUP BY B.user_id) AS exhibit_count,SUM(B.price)AS price FROM order_info A RIGHT JOIN item_info B ON A.item_id=B.item_id LEFT JOIN user_info C ON B.user_id=C.user_id WHERE A.shipping_status=\"完\" AND A.payment_status=\"完\"GROUP BY B.user_id) AS e ON F.item_id=e.item_id GROUP BY F.user_id";

		// "SELECT A.user_id, A.nickname,(SELECT COUNT(B.user_id) FROM item_info GROUP
		// BY B.user_id) AS exhibit_count FROM user_info A inner join item_info B on
		// A.user_id = B.user_id GROUP BY B.user_id";

//		String sql = "SELECT A.user_id, A.nickname,(SELECT COUNT(B.user_id)"
//				+ "FROM item_info GROUP BY B.user_id) AS exhibit_count"
//				+ "FROM user_info A inner join item_info B on A.user_id = B.user_id" + "GROUP BY B.user_id";

		try {
			// データベースに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をオブジェクトに格納
			while (rs.next()) {
				User users = new User();
				users.setUser_id(rs.getString("user_id"));
				users.setNickname(rs.getString("nickname"));
				users.setExhibit_count(rs.getInt("exhibit_count"));
				users.setPrice(rs.getInt("price"));
				users.setUsage_fee(users.getPrice() / 10);

				sellerList.add(users);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return sellerList;

	}

}